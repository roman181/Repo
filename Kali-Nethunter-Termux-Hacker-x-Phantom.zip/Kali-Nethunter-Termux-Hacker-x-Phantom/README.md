# Kali-Nethunter-Termux
Install Kali NetHunter on your Android device through Termux Without Root  with our user-friendly tool. 

![ideas_20240331_151133_0000](https://github.com/hackerxphantom/Kali-Nethunter-Termux/assets/70594016/59097a94-1be7-455a-a8aa-6a931e6cbbda)


```
pkg update -y
```
```
pkg install git -y
```
```
git clone https://github.com/hackerxphantom/Kali-Nethunter-Termux
```
```
cd Kali-Nethunter-Termux
```
```
bash kali-nethunter-phantom.sh
```

## installation video
https://www.instagram.com/reel/C5YPCU9Svb5/?igsh=MXQwZGowbno0NnNncA==

## Thanks for Using my Tool

### Any Error or Prblm u can Contact us
https://bit.ly/3PV3S3r
