# CyberPhish
A heavily armed customizable phishing tool for educational purpose only. It contains phishing email templates of mostly used social media platforms.
# Tutorial:
I have made 3 youtube videos, they delete it, so i purchased our own website to publish scuh amazing blogs. Do check it out.

[Cyber Phish Blog](http://www.cyox2.com/2023/11/cyber-phish-next-generation-of-phishing.html)

# Telegram
* Join Exclusive Educational Telegram Channel https://t.me/cyox2
* Contact me on [Telegram](http://www.cyox2.com/p/contact.html)

# Service
* I will host your phishing site for as long as required without getting banned, for more information dm me on instagram @coding_memz.
* For custom phishing website template dm me on instagram @coding_memz
* For custom phishing page dm me on instagram @coding_memz

# New Release Screenshot
![Screenshot 2023-07-15 133136](https://github.com/Cyber-Dioxide/CyberPhish/assets/93708296/b993cdf0-c884-4423-a775-cc3c58c895c8)

# Custom Template
For creating your own phishing page, phishing template of any website. Dm me on telegram or instagram @coding_memz

# Youtube Tutorial:
- https://www.youtube.com/watch?v=A8OvF2tFirQ

# Motivation
Donate some BTC for future projects
* Btc Wallet: bc1q4lzj4wjfvjj4luta7c0s6vy7cknjvz0e6dku3y

# Usage:
1. apt install python3
2. pip install colorama
3. git clone https://github.com/Cyber-Dioxide/CyberPhish
4. cd CyberPhish
5. ls
6. pip install -r requirements.txt
7. python3 CyberPhish.py
8. !Enjoy!

# 🙌 Donate to Support Development

If you find this tool useful and want to support future updates, you can donate in crypto:

    BTC: 364wCdw46JBGwtk674N4Cj87ErWNVTNvBc

    ETH: 0x4d2c6d55a7ab2874ef5fd172d78da6e553ab9126

    USDT (TRC20): TSgLpf9AawGLnHYRFhp5XqNgLVk7Y7kZBg

    SOL: 3VGJAH5n8NJFKFoC4GPZWay8QJrL5upd33i7WHMpcGpv

    LTC: MASRzRJPy9UxuagdXqzcY9N89NvPMUreNj

Your support helps keep the project alive and free for everyone. Thank you!


# Old Release Screenshot
![CyberPhish](https://user-images.githubusercontent.com/93708296/184074653-fc349ee4-2fe8-4ba7-be34-a8be88bcd4b2.png)

![CyberPhish1](https://user-images.githubusercontent.com/93708296/184074663-3e93f31c-c819-459f-ac7e-93e9d369b45c.png)


# Help
For any question iam mostly active on instagram @cyber_dioxide , @coding_memz
